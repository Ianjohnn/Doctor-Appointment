# DoctorApp

# What you learn after complete these app.
- beautiful Ui Design.
- linearLayout,Relative Layout,GridView,constraint Layout.
- used third party library.
- how to create new activity.
- intent in android studio.
- navigation in android studio.


![Screenshot 2022-11-04 104440](https://user-images.githubusercontent.com/109209762/199899229-6b35e99c-cc38-4796-9eed-8b6b509ed2ed.png)![dashboard](https://user-images.githubusercontent.com/109209762/200123712-56dec74b-9c1c-4b7c-8528-9b690e040cee.png)
